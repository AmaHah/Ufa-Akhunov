import random
import pygame

pygame.init()

white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
green = (0, 155, 0)

width = 800
height = 600

game_display = pygame.display.set_mode((width, height))
pygame.display.set_caption('SnakeGame')

img = pygame.image.load('snake_head.png')

clock = pygame.time.Clock()

snake_side = 20
FPS = 15

direction = "right"

small_insc = pygame.font.SysFont("comicsansms", 25)
med_insc = pygame.font.SysFont("comicsansms", 50)
large_insc = pygame.font.SysFont("comicsansms", 80)


def game_intro():
    intro = True

    while intro:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    intro = False
                if event.key == pygame.K_e:
                    pygame.quit()
                    quit()

        game_display.fill(white)
        message_to_screen("Змейка",
                          green,
                          -100,
                          "large")
        message_to_screen("Ваша задача - есть красные яблоки",
                          black,
                          -30)

        message_to_screen("Чем больше съедите, тем длиннее станете",
                          black,
                          10)

        message_to_screen("Будьте аккуратней: если вы врежетесь, то умрёте!",
                          black,
                          50)

        message_to_screen("Нажмите R, чтобы играть, или E, чтобы выйти.",
                          black,
                          180)

        pygame.display.update()
        clock.tick(15)


def snake(block_side, snake_list):
    if direction == "right":
        head = pygame.transform.rotate(img, 270)

    if direction == "left":
        head = pygame.transform.rotate(img, 90)

    if direction == "up":
        head = img

    if direction == "down":
        head = pygame.transform.rotate(img, 180)

    game_display.blit(head, (snake_list[-1][0], snake_list[-1][1]))

    for XnY in snake_list[:-1]:
        pygame.draw.rect(game_display, green, [XnY[0], XnY[1], snake_side, snake_side])


def text_objects(text, color, size):
    if size == "small":
        text = small_insc.render(text, True, color)
    elif size == "medium":
        text = med_insc.render(text, True, color)
    elif size == "large":
        text = large_insc.render(text, True, color)

    return text, text.get_rect()


def message_to_screen(msg, color, y_displace=0, size="small"):
    text, text_rect = text_objects(msg, color, size)
    text_rect.center = (width / 2), (height / 2) + y_displace
    game_display.blit(text, text_rect)


def game_cycle():
    global direction
    game_exit = False
    game_over = False

    main_x = width / 2
    main_y = height / 2

    main_x_change = 10
    main_y_change = 0

    snake_list = []
    snake_len = 1

    x_apple = round(random.randrange(0, width - snake_side))
    y_apple = round(random.randrange(0, height - snake_side))

    while not game_exit:

        while game_over is True:
            game_display.fill(white)
            message_to_screen("Игра окончена",
                              red,
                              y_displace=-50,
                              size="large")

            message_to_screen("Нажмите R, чтобы играть снова или E, чтобы выйти.",
                              black,
                              50,
                              size="small")
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game_over = False
                    game_exit = True

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_e:
                        game_exit = True
                        game_over = False
                    if event.key == pygame.K_r:
                        game_cycle()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_exit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    direction = "left"
                    main_x_change = -snake_side
                    main_y_change = 0
                elif event.key == pygame.K_RIGHT:
                    direction = "right"
                    main_x_change = snake_side
                    main_y_change = 0
                elif event.key == pygame.K_UP:
                    direction = "up"
                    main_y_change = -snake_side
                    main_x_change = 0
                elif event.key == pygame.K_DOWN:
                    direction = "down"
                    main_y_change = snake_side
                    main_x_change = 0

        if main_x >= width or main_x < 0 or main_y >= height or main_y < 0:
            game_over = True

        main_x += main_x_change
        main_y += main_y_change

        game_display.fill(white)

        apple_size = 30
        pygame.draw.rect(game_display, red, [x_apple, y_apple, apple_size, apple_size])

        snake_head = list()
        snake_head.append(main_x)
        snake_head.append(main_y)
        snake_list.append(snake_head)

        if len(snake_list) > snake_len:
            del snake_list[0]

        for segment in snake_list[:-1]:
            if segment == snake_head:
                game_over = True

        snake(snake_side, snake_list)

        pygame.display.update()

        if x_apple < main_x < x_apple + apple_size or x_apple < main_x + snake_side < x_apple + apple_size:

            if y_apple < main_y < y_apple + apple_size:

                x_apple = round(random.randrange(0, width - snake_side))
                y_apple = round(random.randrange(0, height - snake_side))
                snake_len += 1

            elif y_apple < main_y + snake_side < y_apple + apple_size:

                x_apple = round(random.randrange(0, width - snake_side))
                y_apple = round(random.randrange(0, height - snake_side))
                snake_len += 1

        clock.tick(FPS)

    pygame.quit()
    quit()


game_intro()
game_cycle()
